import tf from '@tensorflow/tfjs-node';
import { TradingStrategy } from './strategy.js';

class MLStrategy extends TradingStrategy {
  constructor() {
    super();
    this.model = this.buildModel();
  }
  
  buildModel() {
    const model = tf.sequential();
    
    model.add(tf.layers.dense({
      units: 64,
      activation: 'relu',
      inputShape: [5] // SMA, RSI, MACD, Signal, Histogram
    }));
    
    model.add(tf.layers.dense({
      units: 32,
      activation: 'relu'
    }));
    
    model.add(tf.layers.dense({
      units: 3, // Buy, Sell, Hold
      activation: 'softmax'
    }));
    
    model.compile({
      optimizer: tf.train.adam(0.001),
      loss: 'categoricalCrossentropy',
      metrics: ['accuracy']
    });
    
    return model;
  }
  
  async train(historicalData, epochs = 50) {
    const signals = super.analyze(historicalData);
    const features = [];
    const labels = [];
    
    // Prepare training data
    for (let i = 0; i < signals.length - 1; i++) {
      const current = signals[i];
      const next = signals[i + 1];
      
      // Feature vector
      features.push([
        current.metrics.sma,
        current.metrics.rsi,
        current.metrics.macd,
        current.metrics.signal,
        current.metrics.histogram
      ]);
      
      // Label: [Buy, Sell, Hold]
      const label = next.price > current.price * 1.001 ? [1, 0, 0] :
                   next.price < current.price * 0.999 ? [0, 1, 0] :
                   [0, 0, 1];
      labels.push(label);
    }
    
    const xs = tf.tensor2d(features);
    const ys = tf.tensor2d(labels);
    
    console.log('Starting model training...');
    await this.model.fit(xs, ys, {
      epochs,
      batchSize: 32,
      validationSplit: 0.2,
      callbacks: {
        onEpochEnd: (epoch, logs) => {
          console.log(`Epoch ${epoch + 1}: loss = ${logs.loss.toFixed(4)}, accuracy = ${logs.acc.toFixed(4)}`);
        }
      }
    });
    
    console.log('Training complete!');
    
    // Clean up tensors
    xs.dispose();
    ys.dispose();
  }
  
  predict(features) {
    const tensor = tf.tensor2d([features]);
    const prediction = this.model.predict(tensor);
    const probabilities = prediction.dataSync();
    tensor.dispose();
    prediction.dispose();
    
    return probabilities;
  }
  
  generateSignal(indicators) {
    const features = [
      indicators.sma,
      indicators.rsi,
      indicators.macd,
      indicators.signal,
      indicators.histogram
    ];
    
    const [buyProb, sellProb, holdProb] = this.predict(features);
    
    let signal = 'HOLD';
    const reasons = [];
    
    if (buyProb > 0.6 && buyProb > sellProb) {
      signal = 'BUY';
      reasons.push(`ML confidence: ${(buyProb * 100).toFixed(2)}%`);
    } else if (sellProb > 0.6 && sellProb > buyProb) {
      signal = 'SELL';
      reasons.push(`ML confidence: ${(sellProb * 100).toFixed(2)}%`);
    }
    
    return {
      ...indicators,
      signal,
      reasons,
      probabilities: { buy: buyProb, sell: sellProb, hold: holdProb }
    };
  }
}

// Example usage
const trainModel = async (historicalData) => {
  const strategy = new MLStrategy();
  await strategy.train(historicalData);
  return strategy;
};

export { MLStrategy, trainModel };