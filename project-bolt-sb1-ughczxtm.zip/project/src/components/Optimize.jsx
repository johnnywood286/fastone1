import React, { useState } from 'react';
import {
  Box,
  Button,
  VStack,
  Slider,
  SliderTrack,
  SliderFilledTrack,
  SliderThumb,
  FormControl,
  FormLabel,
  Text,
} from '@chakra-ui/react';

function Optimize() {
  const [generations, setGenerations] = useState(20);
  const [populationSize, setPopulationSize] = useState(50);
  const [mutationRate, setMutationRate] = useState(0.1);

  return (
    <Box>
      <VStack spacing={6} align="stretch">
        <FormControl>
          <FormLabel>Number of Generations</FormLabel>
          <Slider
            value={generations}
            onChange={setGenerations}
            min={10}
            max={100}
            step={5}
          >
            <SliderTrack>
              <SliderFilledTrack />
            </SliderTrack>
            <SliderThumb />
          </Slider>
          <Text mt={2}>{generations}</Text>
        </FormControl>

        <FormControl>
          <FormLabel>Population Size</FormLabel>
          <Slider
            value={populationSize}
            onChange={setPopulationSize}
            min={20}
            max={200}
            step={10}
          >
            <SliderTrack>
              <SliderFilledTrack />
            </SliderTrack>
            <SliderThumb />
          </Slider>
          <Text mt={2}>{populationSize}</Text>
        </FormControl>

        <FormControl>
          <FormLabel>Mutation Rate</FormLabel>
          <Slider
            value={mutationRate}
            onChange={setMutationRate}
            min={0.01}
            max={0.5}
            step={0.01}
          >
            <SliderTrack>
              <SliderFilledTrack />
            </SliderTrack>
            <SliderThumb />
          </Slider>
          <Text mt={2}>{mutationRate.toFixed(2)}</Text>
        </FormControl>

        <Button colorScheme="blue">Start Optimization</Button>
      </VStack>
    </Box>
  );
}

export default Optimize;