import React from 'react';
import {
  Grid,
  Box,
  Stat,
  StatLabel,
  StatNumber,
  StatHelpText,
  StatArrow,
} from '@chakra-ui/react';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

function Dashboard() {
  const performanceData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
    datasets: [
      {
        label: 'Portfolio Value',
        data: [10000, 10500, 11200, 10800, 11500, 12000],
        borderColor: 'rgb(75, 192, 192)',
        tension: 0.1,
      },
    ],
  };

  return (
    <Box>
      <Grid templateColumns="repeat(4, 1fr)" gap={6} mb={8}>
        <Stat bg="white" p={4} borderRadius="lg" shadow="sm">
          <StatLabel>Total Profit</StatLabel>
          <StatNumber>$2,000</StatNumber>
          <StatHelpText>
            <StatArrow type="increase" />
            20%
          </StatHelpText>
        </Stat>
        <Stat bg="white" p={4} borderRadius="lg" shadow="sm">
          <StatLabel>Win Rate</StatLabel>
          <StatNumber>65%</StatNumber>
          <StatHelpText>Last 100 trades</StatHelpText>
        </Stat>
        <Stat bg="white" p={4} borderRadius="lg" shadow="sm">
          <StatLabel>Sharpe Ratio</StatLabel>
          <StatNumber>1.8</StatNumber>
          <StatHelpText>Risk-adjusted return</StatHelpText>
        </Stat>
        <Stat bg="white" p={4} borderRadius="lg" shadow="sm">
          <StatLabel>Max Drawdown</StatLabel>
          <StatNumber>-12%</StatNumber>
          <StatHelpText>Historical maximum</StatHelpText>
        </Stat>
      </Grid>
      
      <Box bg="white" p={6} borderRadius="lg" shadow="sm">
        <Line data={performanceData} options={{
          responsive: true,
          plugins: {
            title: {
              display: true,
              text: 'Portfolio Performance'
            }
          }
        }} />
      </Box>
    </Box>
  );
}

export default Dashboard;