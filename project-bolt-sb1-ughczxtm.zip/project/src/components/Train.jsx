import React, { useState } from 'react';
import {
  Box,
  Button,
  VStack,
  FormControl,
  FormLabel,
  NumberInput,
  NumberInputField,
  NumberInputStepper,
  NumberIncrementStepper,
  NumberDecrementStepper,
  Progress,
  Text,
} from '@chakra-ui/react';

function Train() {
  const [epochs, setEpochs] = useState(50);
  const [batchSize, setBatchSize] = useState(32);
  const [isTraining, setIsTraining] = useState(false);
  const [progress, setProgress] = useState(0);

  const startTraining = () => {
    setIsTraining(true);
    setProgress(0);
    
    // Simulate training progress
    const interval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsTraining(false);
          return 100;
        }
        return prev + 2;
      });
    }, 500);
  };

  return (
    <Box>
      <VStack spacing={6} align="stretch">
        <FormControl>
          <FormLabel>Number of Epochs</FormLabel>
          <NumberInput value={epochs} onChange={(_, val) => setEpochs(val)} min={1} max={200}>
            <NumberInputField />
            <NumberInputStepper>
              <NumberIncrementStepper />
              <NumberDecrementStepper />
            </NumberInputStepper>
          </NumberInput>
        </FormControl>

        <FormControl>
          <FormLabel>Batch Size</FormLabel>
          <NumberInput value={batchSize} onChange={(_, val) => setBatchSize(val)} min={8} max={128} step={8}>
            <NumberInputField />
            <NumberInputStepper>
              <NumberIncrementStepper />
              <NumberDecrementStepper />
            </NumberInputStepper>
          </NumberInput>
        </FormControl>

        <Button
          colorScheme="blue"
          onClick={startTraining}
          isLoading={isTraining}
          loadingText="Training..."
        >
          Start Training
        </Button>

        {isTraining && (
          <Box>
            <Text mb={2}>Training Progress: {progress}%</Text>
            <Progress value={progress} size="sm" colorScheme="blue" />
          </Box>
        )}
      </VStack>
    </Box>
  );
}

export default Train;