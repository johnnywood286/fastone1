import React, { useState } from 'react';
import {
  Box,
  Button,
  FormControl,
  FormLabel,
  Input,
  VStack,
  HStack,
  Text,
  Progress,
} from '@chakra-ui/react';

function Backtest() {
  const [isRunning, setIsRunning] = useState(false);
  const [progress, setProgress] = useState(0);

  const runBacktest = () => {
    setIsRunning(true);
    setProgress(0);
    
    // Simulate backtest progress
    const interval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsRunning(false);
          return 100;
        }
        return prev + 10;
      });
    }, 500);
  };

  return (
    <Box>
      <VStack spacing={6} align="stretch">
        <FormControl>
          <FormLabel>Start Date</FormLabel>
          <Input type="date" />
        </FormControl>
        
        <FormControl>
          <FormLabel>End Date</FormLabel>
          <Input type="date" />
        </FormControl>
        
        <FormControl>
          <FormLabel>Initial Capital</FormLabel>
          <Input type="number" defaultValue={10000} />
        </FormControl>
        
        <HStack>
          <Button
            colorScheme="blue"
            onClick={runBacktest}
            isLoading={isRunning}
            loadingText="Running..."
          >
            Run Backtest
          </Button>
          <Button variant="outline">Reset</Button>
        </HStack>
        
        {isRunning && (
          <Box>
            <Text mb={2}>Progress: {progress}%</Text>
            <Progress value={progress} size="sm" colorScheme="blue" />
          </Box>
        )}
      </VStack>
    </Box>
  );
}

export default Backtest;