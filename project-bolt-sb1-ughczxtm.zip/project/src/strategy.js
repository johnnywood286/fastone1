import { SMA, RSI, MACD } from 'technicalindicators';

export class TradingStrategy {
  constructor(params = {}) {
    this.params = {
      smaLength: params.smaLength || 20,
      rsiLength: params.rsiLength || 14,
      rsiOverbought: params.rsiOverbought || 70,
      rsiOversold: params.rsiOversold || 30,
      macdFast: params.macdFast || 12,
      macdSlow: params.macdSlow || 26,
      macdSignal: params.macdSignal || 9,
      stopLoss: params.stopLoss || 2, // percentage
      takeProfit: params.takeProfit || 3 // percentage
    };
  }

  analyze(candles) {
    const closes = candles.map(c => c.close);
    
    // Calculate indicators
    const sma = SMA.calculate({
      period: this.params.smaLength,
      values: closes
    });

    const rsi = RSI.calculate({
      period: this.params.rsiLength,
      values: closes
    });

    const macd = MACD.calculate({
      fastPeriod: this.params.macdFast,
      slowPeriod: this.params.macdSlow,
      signalPeriod: this.params.macdSignal,
      values: closes
    });

    // Generate signals
    const signals = [];
    const offset = Math.max(this.params.smaLength, this.params.rsiLength, 
      this.params.macdSlow + this.params.macdSignal);

    for (let i = offset; i < closes.length; i++) {
      const signal = this.generateSignal({
        price: closes[i],
        sma: sma[i - offset + sma.length - 1],
        rsi: rsi[i - offset + rsi.length - 1],
        macd: macd[i - offset + macd.length - 1],
        timestamp: candles[i].timestamp
      });
      
      signals.push(signal);
    }

    return signals;
  }

  generateSignal({ price, sma, rsi, macd, timestamp }) {
    let signal = 'HOLD';
    const reasons = [];

    // Buy conditions
    if (
      price > sma && // Price above SMA (uptrend)
      rsi < this.params.rsiOversold && // RSI oversold
      macd && // Check if MACD exists
      macd.histogram > 0 && // MACD histogram positive
      macd.MACD_line > macd.signal_line // MACD line crossing above signal line
    ) {
      signal = 'BUY';
      reasons.push('Price above SMA', 'RSI oversold', 'MACD bullish crossover');
    }
    
    // Sell conditions
    else if (
      price < sma && // Price below SMA (downtrend)
      rsi > this.params.rsiOverbought && // RSI overbought
      macd && // Check if MACD exists
      macd.histogram < 0 && // MACD histogram negative
      macd.MACD_line < macd.signal_line // MACD line crossing below signal line
    ) {
      signal = 'SELL';
      reasons.push('Price below SMA', 'RSI overbought', 'MACD bearish crossover');
    }

    return {
      timestamp,
      price,
      signal,
      reasons,
      metrics: {
        sma,
        rsi,
        macd: macd ? macd.MACD_line : null,
        signal: macd ? macd.signal_line : null,
        histogram: macd ? macd.histogram : null
      }
    };
  }
}