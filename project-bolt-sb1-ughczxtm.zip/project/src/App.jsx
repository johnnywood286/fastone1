import React, { useState } from 'react';
import {
  Box,
  Container,
  Tabs,
  TabList,
  TabPanels,
  Tab,
  TabPanel,
  Heading,
} from '@chakra-ui/react';
import Dashboard from './components/Dashboard';
import Backtest from './components/Backtest';
import Optimize from './components/Optimize';
import Train from './components/Train';

function App() {
  return (
    <Box minH="100vh" bg="gray.50">
      <Container maxW="container.xl" py={8}>
        <Heading mb={8} textAlign="center">Trading Bot Dashboard</Heading>
        <Tabs variant="enclosed" colorScheme="blue">
          <TabList>
            <Tab>Dashboard</Tab>
            <Tab>Backtest</Tab>
            <Tab>Optimize</Tab>
            <Tab>Train</Tab>
          </TabList>
          <TabPanels>
            <TabPanel>
              <Dashboard />
            </TabPanel>
            <TabPanel>
              <Backtest />
            </TabPanel>
            <TabPanel>
              <Optimize />
            </TabPanel>
            <TabPanel>
              <Train />
            </TabPanel>
          </TabPanels>
        </Tabs>
      </Container>
    </Box>
  );
}

export default App;