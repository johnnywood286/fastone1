import { TradingStrategy } from './strategy.js';
import { geneticOptimizer } from './optimizers/genetic.js';

const optimize = async (historicalData) => {
  console.log('Starting parameter optimization...');
  
  const parameterRanges = {
    smaLength: { min: 5, max: 50, step: 5 },
    rsiLength: { min: 7, max: 21, step: 2 },
    rsiOverbought: { min: 65, max: 85, step: 5 },
    rsiOversold: { min: 15, max: 35, step: 5 },
    macdFast: { min: 8, max: 20, step: 2 },
    macdSlow: { min: 20, max: 40, step: 4 },
    stopLoss: { min: 0.5, max: 5, step: 0.5 },
    takeProfit: { min: 1, max: 10, step: 1 }
  };

  const result = await geneticOptimizer(historicalData, parameterRanges, {
    populationSize: 50,
    generations: 20,
    mutationRate: 0.1,
    crossoverRate: 0.8
  });

  console.log('Optimization complete!');
  console.log('Best parameters:', result.bestParameters);
  console.log('Performance metrics:', result.metrics);
  
  return result;
};

export { optimize };