import { TradingStrategy } from '../strategy.js';

export const geneticOptimizer = async (data, paramRanges, options) => {
  let population = initializePopulation(options.populationSize, paramRanges);
  let bestSolution = null;
  
  for (let gen = 0; gen < options.generations; gen++) {
    const evaluated = await evaluatePopulation(population, data);
    population = selection(evaluated, options);
    population = crossover(population, options.crossoverRate);
    population = mutation(population, paramRanges, options.mutationRate);
    
    const generationBest = evaluated[0];
    if (!bestSolution || generationBest.fitness > bestSolution.fitness) {
      bestSolution = generationBest;
    }
    
    console.log(`Generation ${gen + 1}/${options.generations}`);
    console.log(`Best fitness: ${bestSolution.fitness}`);
  }
  
  return {
    bestParameters: bestSolution.parameters,
    metrics: {
      profit: bestSolution.fitness,
      sharpeRatio: calculateSharpeRatio(bestSolution.returns),
      maxDrawdown: calculateMaxDrawdown(bestSolution.returns)
    }
  };
};

function initializePopulation(size, ranges) {
  return Array.from({ length: size }, () => {
    const parameters = {};
    for (const [param, range] of Object.entries(ranges)) {
      parameters[param] = randomInRange(range.min, range.max, range.step);
    }
    return parameters;
  });
}

async function evaluatePopulation(population, data) {
  const evaluated = await Promise.all(
    population.map(async params => {
      const strategy = new TradingStrategy(params);
      const results = await backtest(strategy, data);
      return {
        parameters: params,
        fitness: calculateFitness(results),
        returns: results.returns
      };
    })
  );
  
  return evaluated.sort((a, b) => b.fitness - a.fitness);
}

function selection(evaluated, options) {
  const selected = [];
  while (selected.length < options.populationSize) {
    const tournament = shuffleArray(evaluated)
      .slice(0, 3);
    selected.push(tournament[0].parameters);
  }
  return selected;
}

function crossover(population, rate) {
  const newPopulation = [];
  
  for (let i = 0; i < population.length; i += 2) {
    if (Math.random() < rate && i + 1 < population.length) {
      const [child1, child2] = crossoverPair(
        population[i],
        population[i + 1]
      );
      newPopulation.push(child1, child2);
    } else {
      newPopulation.push(population[i]);
      if (i + 1 < population.length) {
        newPopulation.push(population[i + 1]);
      }
    }
  }
  
  return newPopulation;
}

function mutation(population, ranges, rate) {
  return population.map(individual => {
    const mutated = { ...individual };
    for (const [param, range] of Object.entries(ranges)) {
      if (Math.random() < rate) {
        mutated[param] = randomInRange(range.min, range.max, range.step);
      }
    }
    return mutated;
  });
}

function randomInRange(min, max, step) {
  const steps = Math.floor((max - min) / step);
  return min + (Math.floor(Math.random() * steps) * step);
}

function shuffleArray(array) {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}

function calculateFitness(results) {
  const { totalProfit, winRate, sharpeRatio } = results;
  return (totalProfit * 0.4) + (winRate * 0.3) + (sharpeRatio * 0.3);
}

function calculateSharpeRatio(returns) {
  const mean = returns.reduce((a, b) => a + b, 0) / returns.length;
  const variance = returns.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / returns.length;
  const stdDev = Math.sqrt(variance);
  return mean / stdDev;
}

function calculateMaxDrawdown(returns) {
  let peak = -Infinity;
  let maxDrawdown = 0;
  
  for (const value of returns) {
    if (value > peak) peak = value;
    const drawdown = (peak - value) / peak;
    if (drawdown > maxDrawdown) maxDrawdown = drawdown;
  }
  
  return maxDrawdown;
}

async function backtest(strategy, data) {
  const signals = strategy.analyze(data);
  let balance = 10000;
  let position = null;
  const returns = [];
  
  for (const signal of signals) {
    if (signal.signal === 'BUY' && !position) {
      position = { price: signal.price, size: balance * 0.95 / signal.price };
      balance -= position.size * signal.price;
    } else if (signal.signal === 'SELL' && position) {
      const profit = position.size * (signal.price - position.price);
      balance += (position.size * signal.price);
      returns.push(profit / (position.size * position.price));
      position = null;
    }
  }
  
  return {
    totalProfit: balance - 10000,
    winRate: returns.filter(r => r > 0).length / returns.length,
    returns
  };
}