import { TradingStrategy } from './strategy.js';

class StrategyAnalyzer {
  constructor() {
    this.results = [];
  }

  async analyzeParameters(candles, parameterRanges) {
    console.log('Starting strategy parameter analysis...');

    // Generate parameter combinations
    const combinations = this.generateParameterCombinations(parameterRanges);
    
    for (const params of combinations) {
      const strategy = new TradingStrategy(params);
      const result = this.testStrategy(strategy, candles);
      this.results.push({ params, ...result });
    }

    this.printResults();
  }

  generateParameterCombinations(ranges) {
    const combinations = [{}];
    
    for (const [param, values] of Object.entries(ranges)) {
      const newCombinations = [];
      for (const combo of combinations) {
        for (const value of values) {
          newCombinations.push({ ...combo, [param]: value });
        }
      }
      combinations.length = 0;
      combinations.push(...newCombinations);
    }

    return combinations;
  }

  testStrategy(strategy, candles) {
    const signals = strategy.analyze(candles);
    let balance = 10000;
    let position = null;
    const trades = [];

    for (const signal of signals) {
      const { price, signal: action } = signal;

      if (action === 'BUY' && !position) {
        const amount = balance * 0.95;
        const shares = amount / price;
        position = { price, shares };
        balance -= amount;
        trades.push({ type: 'BUY', price, shares });
      }
      else if (action === 'SELL' && position) {
        const amount = position.shares * price;
        balance += amount;
        trades.push({
          type: 'SELL',
          price,
          shares: position.shares,
          profit: amount - (position.shares * position.price)
        });
        position = null;
      }
    }

    const profitableTrades = trades.filter(t => t.type === 'SELL' && t.profit > 0).length;
    const totalProfit = balance - 10000;
    const winRate = (profitableTrades / (trades.length/2)) * 100;

    return {
      totalTrades: trades.length,
      profitableTrades,
      winRate,
      totalProfit,
      profitPercent: (totalProfit / 10000) * 100
    };
  }

  printResults() {
    console.log('\nStrategy Analysis Results:');
    console.log('=========================');

    // Sort results by profit percentage
    this.results.sort((a, b) => b.profitPercent - a.profitPercent);

    // Print top 5 performing parameter combinations
    console.log('\nTop 5 Parameter Combinations:');
    this.results.slice(0, 5).forEach((result, i) => {
      console.log(`\n#${i + 1} Performance:`);
      console.log('Parameters:', result.params);
      console.log(`Total Trades: ${result.totalTrades}`);
      console.log(`Win Rate: ${result.winRate.toFixed(2)}%`);
      console.log(`Profit: $${result.totalProfit.toFixed(2)} (${result.profitPercent.toFixed(2)}%)`);
    });
  }
}

// Example usage with sample data and parameter ranges
const sampleData = [
  // Generate some sample price data for testing
  ...Array(100).fill(0).map((_, i) => ({
    timestamp: new Date(2023, 0, i + 1).toISOString(),
    open: 100 + Math.sin(i * 0.1) * 10,
    high: 105 + Math.sin(i * 0.1) * 10,
    low: 95 + Math.sin(i * 0.1) * 10,
    close: 100 + Math.sin(i * 0.1) * 10,
    volume: 1000000 + Math.random() * 500000
  }))
];

const parameterRanges = {
  smaLength: [10, 20, 30],
  rsiLength: [9, 14, 21],
  rsiOverbought: [70, 75, 80],
  rsiOversold: [20, 25, 30],
  macdFast: [12, 15],
  macdSlow: [26, 30],
  stopLoss: [2, 3, 4],
  takeProfit: [3, 4, 5]
};

const analyzer = new StrategyAnalyzer();
analyzer.analyzeParameters(sampleData, parameterRanges);