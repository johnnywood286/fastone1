import { TradingStrategy } from './strategy.js';

class Backtester {
  constructor(initialBalance = 10000) {
    this.initialBalance = initialBalance;
    this.balance = initialBalance;
    this.position = null;
    this.trades = [];
    this.strategy = new TradingStrategy();
  }

  async run(candles) {
    console.log('Starting backtest...');
    console.log(`Initial balance: $${this.initialBalance}`);

    const signals = this.strategy.analyze(candles);
    
    for (const signal of signals) {
      this.processSignal(signal);
    }

    this.printResults();
  }

  processSignal(signal) {
    const { price, signal: action } = signal;

    if (action === 'BUY' && !this.position) {
      const amount = this.balance * 0.95; // Use 95% of balance for position
      const shares = amount / price;
      this.position = { price, shares };
      this.balance -= amount;
      
      this.trades.push({
        type: 'BUY',
        price,
        shares,
        timestamp: signal.timestamp,
        reasons: signal.reasons
      });
    }
    else if (action === 'SELL' && this.position) {
      const amount = this.position.shares * price;
      this.balance += amount;
      
      const profit = amount - (this.position.shares * this.position.price);
      const profitPercent = (profit / (this.position.shares * this.position.price)) * 100;

      this.trades.push({
        type: 'SELL',
        price,
        shares: this.position.shares,
        profit,
        profitPercent,
        timestamp: signal.timestamp,
        reasons: signal.reasons
      });

      this.position = null;
    }
  }

  printResults() {
    console.log('\nBacktest Results:');
    console.log('================');
    
    const totalTrades = this.trades.length;
    const profitableTrades = this.trades.filter(t => t.type === 'SELL' && t.profit > 0).length;
    const totalProfit = this.balance - this.initialBalance;
    const profitPercent = (totalProfit / this.initialBalance) * 100;

    console.log(`Total Trades: ${totalTrades}`);
    console.log(`Profitable Trades: ${profitableTrades}`);
    console.log(`Win Rate: ${((profitableTrades / (totalTrades/2)) * 100).toFixed(2)}%`);
    console.log(`Final Balance: $${this.balance.toFixed(2)}`);
    console.log(`Total Profit: $${totalProfit.toFixed(2)} (${profitPercent.toFixed(2)}%)`);
    
    console.log('\nDetailed Trade History:');
    console.log('=====================');
    this.trades.forEach((trade, i) => {
      console.log(`\nTrade #${i + 1}`);
      console.log(`Type: ${trade.type}`);
      console.log(`Price: $${trade.price.toFixed(2)}`);
      console.log(`Shares: ${trade.shares.toFixed(4)}`);
      if (trade.profit !== undefined) {
        console.log(`Profit: $${trade.profit.toFixed(2)} (${trade.profitPercent.toFixed(2)}%)`);
      }
      console.log(`Reasons: ${trade.reasons.join(', ')}`);
    });
  }
}

// Example usage with sample data
const sampleData = [
  // Generate some sample price data for testing
  ...Array(100).fill(0).map((_, i) => ({
    timestamp: new Date(2023, 0, i + 1).toISOString(),
    open: 100 + Math.sin(i * 0.1) * 10,
    high: 105 + Math.sin(i * 0.1) * 10,
    low: 95 + Math.sin(i * 0.1) * 10,
    close: 100 + Math.sin(i * 0.1) * 10,
    volume: 1000000 + Math.random() * 500000
  }))
];

const backtester = new Backtester();
backtester.run(sampleData);